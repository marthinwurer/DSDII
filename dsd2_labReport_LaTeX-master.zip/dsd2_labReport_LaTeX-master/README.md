# labReportTemplate_LaTeX
This is a lab report template in LaTeX for Digital Systems Design II. I have tried to make it as simple as possible to use (AKA tons of comments), so I hope this is a good way for newcomers to learn and meddle around with this amazing technology. 

INSTRUCTIONS ON HOW TO USE THIS TEMPLATE AND/OR SET UP LATEX AND AN EDITOR:

I. For people who already have LaTeX set up with an editor:
  1. Download the .zip file
  2. Extract all files and folders as is into your desired location
  3. Run the coverPage.tex file.
  
II. For people who have not set up LaTeX:
  1. Download a LaTeX distribution. MiKTeX for Windows, MacTeX for MacOS, and TeX Live for Linux shall suffice.
  2. Install an editor. TeXStudio is awesome AND it is on Windows, Mac, and Linux. You can also use an online site called OverLeaf which        lets you save, edit, and compile real-time into .PDF as you edit. The only problem is that it does not have a lot of space, so it can      fill up fairly quickly.
  3. Now you have LaTeX and an editor set up! Go to the Section I for the rest of the instructions.
  
  Happy Lab Writing! Hope this helps!
